const list = document.getElementById("task-list");
let draggingEle;

list.addEventListener("dragstart", (e) => {
  draggingEle = e.target;
  e.target.classList.add("dragging");
});

list.addEventListener("dragend", () => {
  draggingEle.classList.remove("dragging");
  const newOrder = Array.from(list.children).map(li => li.getAttribute('data-id'));
  fetch("/reorder", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ order: newOrder }),
  });
});

list.addEventListener("dragover", (e) => {
  e.preventDefault();
  const afterElement = getDragAfterElement(list, e.clientY);
  const dragging = document.querySelector(".dragging");
  if (afterElement == null) {
    list.appendChild(dragging);
  } else {
    list.insertBefore(dragging, afterElement);
  }
});

function getDragAfterElement(container, y) {
  const items = [...container.querySelectorAll("li:not(.dragging)")];
  return items.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    return offset < 0 && offset > closest.offset ? { offset, element: child } : closest;
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

document.querySelectorAll("#task-list li").forEach(item => {
  item.setAttribute("draggable", "true");
});
