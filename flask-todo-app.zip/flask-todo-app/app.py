from flask import Flask, render_template, request, redirect, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB = 'todo.db'

def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                due_date TEXT,
                completed INTEGER DEFAULT 0,
                position INTEGER
            )
        ''')
        conn.commit()

@app.route('/')
def index():
    with sqlite3.connect(DB) as conn:
        tasks = conn.execute("SELECT * FROM tasks ORDER BY position ASC").fetchall()
    return render_template('index.html', tasks=tasks)

@app.route('/add', methods=['POST'])
def add():
    content = request.form['content']
    due_date = request.form['due_date']
    with sqlite3.connect(DB) as conn:
        max_pos = conn.execute("SELECT MAX(position) FROM tasks").fetchone()[0]
        new_pos = (max_pos or 0) + 1
        conn.execute("INSERT INTO tasks (content, due_date, position) VALUES (?, ?, ?)", 
                     (content, due_date, new_pos))
        conn.commit()
    return redirect('/')

@app.route('/delete/<int:task_id>')
def delete(task_id):
    with sqlite3.connect(DB) as conn:
        conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        conn.commit()
    return redirect('/')

@app.route('/complete/<int:task_id>')
def complete(task_id):
    with sqlite3.connect(DB) as conn:
        conn.execute("UPDATE tasks SET completed = NOT completed WHERE id = ?", (task_id,))
        conn.commit()
    return redirect('/')

@app.route('/reorder', methods=['POST'])
def reorder():
    order = request.json['order']
    with sqlite3.connect(DB) as conn:
        for idx, task_id in enumerate(order):
            conn.execute("UPDATE tasks SET position = ? WHERE id = ?", (idx, task_id))
        conn.commit()
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
